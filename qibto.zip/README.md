QIBTO is an motor driving training school app !

How to run qibto project ?

Go to project root folder & run command "npm install" !

If node_modules installed successfully into your project then run command "npm start" in your root folder!

Test your app in browser by http://localhost:3000 !

If you are on live server then just visit your site url like http://www.yourwebsite.com !


This project is developed under www.cyberframe.in !

Author 

Amit Dubey